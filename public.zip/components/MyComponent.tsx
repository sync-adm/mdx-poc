import React, { HTMLAttributes } from 'react'

export interface MyComponentProps {
    nome: string,
    backgroundColor: string
}

function MyComponent(props: MyComponentProps) {
    console.log(props);
  return (
    <div style={{backgroundColor: props.backgroundColor}}>Olá, {props.nome}!</div>
  )
}

export default MyComponent